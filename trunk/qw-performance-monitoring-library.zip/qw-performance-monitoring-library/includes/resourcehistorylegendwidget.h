/*
Copyright (c) 2011 by Bob K Danani
See the file license.txt for copying permission.
*/


#ifndef RESOURCE_HISTORY_LEGEND_WIDGET_H
#define RESOURCE_HISTORY_LEGEND_WIDGET_H

#include "resourcehistorydatagroup.h"
#include <vector>
#include <iostream>
#include <sstream>
#include <QtCore/qstringlist.h>
#include <QtGui/qcolor.h>
#include <QtGui/qlabel.h>
#include <QtGui/qgroupbox.h>
#include <QtGui/qgridlayout.h>
#include <QtGui/qtablewidget.h>
#include <QtGui/qheaderview.h>
#include <QtGui/qpushbutton.h>


using namespace std;

class ResourceHistoryLegendWidget : public QWidget
{
    Q_OBJECT

public:
    //PUBLIC FUNCTIONS
    ResourceHistoryLegendWidget();
    ~ResourceHistoryLegendWidget();
    QSize   minimumSizeHint() const;
    QSize   sizeHint() const;

    //adding or updating datagroups
    //In order for all datagroups in the ResourceHistoryWidget to show up in the legend, the addDatagroup function has to be called for each of the datagroups
    void    addDatagroup (ResourceHistoryDatagroup *datagroup); // to add the datagroup to be represented in the legend
    // The updateDatagroup function is used to update the performance values for each datagroup, so that the legend can show the most updated values
    void    updateDatagroup (int index, ResourceHistoryDatagroup *datagroup);
    //this function has to be called after the updateDatagroup () function is called.
    //you can firstly call the updateDatagroup function for each datagroup that you have, and after that just call the refreshLegendData() once
    void    refreshLegendData();

    // visibility of each columns in this legend widget
    bool    isColorVisible ();
    void    setColorVisible (bool visible);
    bool    isDatagroupVisible ();
    void    setDatagroupVisible (bool visible);
    bool    isValueVisible ();
    void    setValueVisible (bool visible);
    bool    isHighestPeakValueVisible ();
    void    setHighestPeakValueVisible (bool visible);
    bool    isLowestPeakValueVisible ();
    void    setLowestPeakValueVisible (bool visible);

    //color setting
    QColor  getTextColor ();
    void    setTextColor (QColor textColor);

    //header parameter configurations
    QString getColorLabelText ();
    void    setColorLabelText (QString colorLabelText);
    void    setColorLabelText (char* colorLabelText);
    QString getDatagroupLabelText ();
    void    setDatagroupLabelText (QString datagroupLabelText);
    void    setDatagroupLabelText (char* datagroupLabelText);
    QString getValueLabelText ();
    void    setValueLabelText (QString valueLabelText);
    void    setValueLabelText (char* valueLabelText);
    QString getHighestPeakLabelText ();
    void    setHighestPeakLabelText (QString highestPeakLabelText);
    void    setHighestPeakLabelText (char* highestPeakLabelText);
    QString getLowestPeakLabelText ();
    void    setLowestPeakLabelText (QString lowestPeakLabelText);
    void    setLowestPeakLabelText (char* lowestPeakLabelText);

    //this function has to be called everytime the header related parameters (above) are modified
    //so that the changes will affect the legend header display
    void    refreshLegendHeader ();

    //widget main title
    QString getTitle ();
    void    setTitle (QString title);
    void    setTitle (char* title);

private:
    vector <ResourceHistoryDatagroup> *datagroups;

    //header related parameters
    QString colorLabelText;
    QString datagroupLabelText;
    QString valueLabelText;
    QString highestPeakLabelText;
    QString lowestPeakLabelText;

    //legend main title
    QString title;

    //show or hide particular columns in the legend display
    bool    showColor;
    bool    showDatagoup;
    bool    showValue;
    bool    showHighestPeak;
    bool    showLowestPeak;

    QColor  textColor;

    QTableWidget *table;
    QGroupBox *contentGroupBox;

private:
    QString getTextStyleSheet(int red, int green, int blue);
    QString getBackgroundStyleSheet (int red, int green, int blue);
};

#endif // RESOURCE_HISTORY_LEGEND_WIDGET_H
