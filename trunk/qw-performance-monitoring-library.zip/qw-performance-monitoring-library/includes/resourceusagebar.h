/*
Copyright (c) 2011 by Bob K Danani
See the file license.txt for copying permission.
*/

/*
 * This internal class will be instantiated by the ResourceUsageWidget class.
 * This class does not have any public functions or variables.
 */

#ifndef RESOURCE_USAGE_BAR_H
#define RESOURCE_USAGE_BAR_H

#include <iostream>
#include <vector>
#include <QtOpenGL/qgl.h>
#include <QtGui/qlabel.h>
#include <QtGui/qcolor.h>
#include <QtCore/qstring.h>

using namespace std;

class ResourceUsageBar : public QGLWidget
{
    Q_OBJECT

protected:
    friend class ResourceUsageWidget;
    ResourceUsageBar(QWidget *parent = 0);
    ~ResourceUsageBar();
    QSize   minimumSizeHint() const;
    QSize   sizeHint() const;
    void    initializeGL();
    void    paintGL();
    void    resizeGL(int width, int height);

private: // private attributes
    int     gridDensity;
    QColor  gridBackgroundColor;
    QColor  performanceBarColor;
    float   currentValue;
    float   maximum;
    bool    antialiasingEnabled;
    vector <float> horizontalGrids;

private: // private functions
    void    drawUsageBar();
    int     getCurrentValue ();
    void    setCurrentValue(float value);
    float   getMaximum ();
    void    setMaximum(float maximum);
    int     getGridDensity();
    void    setGridDensity(int gridDensity);
    QColor  getPerformanceBarColor();
    void    setPerformanceBarColor (QColor performanceBarColor);
    QColor  getGridBackgroundColor();
    void    setGridBackgroundColor (QColor gridBackgroundColor);
    void    setAntialiasing (bool antialiasingEnabled);
    bool    isAntialiasingEnabled ();
};
#endif // RESOURCE_USAGE_BAR_H
