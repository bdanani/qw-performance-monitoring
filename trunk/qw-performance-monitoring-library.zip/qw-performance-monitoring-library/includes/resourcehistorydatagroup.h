/*
Copyright (c) 2011 by Bob K Danani
See the file license.txt for copying permission.
*/

#ifndef RESOURCE_HISTORY_DATAGROUP_H
#define RESOURCE_HISTORY_DATAGROUP_H

#include "resourcehistorychart.h"
#include <vector>
#include <QtGui/qcolor.h>

using namespace std;
class ResourceHistoryChart;

typedef struct Point {
        float x;
        float y;
} Point;

class ResourceHistoryDatagroup
{
public:
    // for this to function well (to reflect the display in the ResourceHistoryWidget correctly), the size parameter here must be set to => gridWidth*timeFrameEachGrid
    ResourceHistoryDatagroup(int size = 0, const char* label = "");

    //datagroup configurations
    string  getLabel();
    void    setLabel(string label);
    QColor  getLineColor ();
    void    setLineColor (QColor lineColor);
    bool    isLineVisible ();
    void    setLineVisible (bool visible);
    float   getLineWidth ();
    void    setLineWidth (float lineWidth);
    float   getCurrentValue();
    void    setCurrentValue(float value);
    float   getHighestPeakValue ();
    float   getLowestPeakValue ();

private: // private attributes
    friend class ResourceHistoryChart;
    int     size;
    string  label;
    QColor  lineColor;
    bool    showLine;
    float   lineWidth;
    float   currentValue;
    float   highestPeakValue;
    float   lowestPeakValue;
    vector <Point> performanceLines;

 private: // private functions
    void    initialize(int size);
    void    setHighestPeakValue (float highestPeakValue);
    void    setLowestPeakValue (float lowestPeakValue);
};
#endif // RESOURCE_HISTORY_DATAGROUP_H
