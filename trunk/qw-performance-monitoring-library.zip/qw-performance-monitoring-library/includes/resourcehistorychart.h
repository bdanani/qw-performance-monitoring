/*
Copyright (c) 2011 by Bob K Danani
See the file license.txt for copying permission.
*/

/*
 * This internal class will be instantiated by the ResouceHistoryUsageWidget class.
 * This class does not have any public functions or variables.
 */

#ifndef RESOURCE_HISTORY_CHART_H
#define RESOURCE_HISTORY_CHART_H

#include "resourcehistorydatagroup.h"
#include <QtCore/qsize.h>
#include <QtOpenGL/qgl.h>
#include <QtCore/qtimer.h>
#include <vector>
#include <iostream>

using namespace std;
class ResourceHistoryDatagroup;

class ResourceHistoryChart : public QGLWidget
{
    Q_OBJECT

protected:
    //this contructor and destructor is declared as protected so this class cannot be instantiated, except by the ResourceHistoryWidget class (friend class)
    friend class ResourceHistoryWidget;
    ResourceHistoryChart(QWidget *parent = 0);
    ~ResourceHistoryChart();
    QSize   minimumSizeHint() const;
    QSize   sizeHint() const;
    void    initializeGL();
    void    paintGL();
    void    resizeGL(int width, int height);

private:
    int     gridWidth;
    int     gridHeight;
    int     timeFrameEachGrid;
    int     timeFrameWidth;
    bool    showGrid;
    bool    showLine;
    bool    moveGrid;
    long    updateFrequency; // in millisecond
    int     timeframe;

    // a copy timeframe variable.
    // This one is to be used only if the gridMove variable is set to true, for the purpose of toggling the behavior of moving or unmoving the grid
    // we need to preserve the correct timeframe value since the last time the grid was toggled.
    int     timeframeForMovingGrid;
    float   maximum; // maximum scale
    bool    antialiasingEnabled;

    QColor  gridColor;
    QColor  backgroundColor;

    //Mean Statistic
    float   meanValue;
    bool    showMean;
    ResourceHistoryDatagroup *meanDataGroup;

    vector <ResourceHistoryDatagroup> *datagroups;
    vector <float> verticalGrids;
    vector <float> horizontalGrids;

private:
    // PRIVATE FUNCTIONS
    void    drawLines ();
    void    drawLine (ResourceHistoryDatagroup datagroup);
    void    initializeWidget (vector<float>& horizontalGrids, vector<float>& verticalGrids);
    void    drawGrid (vector<float>& horizontalGrids, vector<float>& verticalGrids);
    void    reInitializeAllDataGroups ();

    void    refreshChartDrawable();
    void    reInitializeChart();
    float   getMaximum ();
    void    setMaximum (float max);
    QColor  getGridColor ();
    void    setGridColor (QColor gridColor);
    QColor  getBackgroundColor ();
    void    setBackgroundColor (QColor backgroundColor);
    bool    isGridVisible ();
    void    setGridVisible (bool visible);
    int     getGridHeight ();
    void    setGridHeight (int h);
    int     getGridWidth ();
    void    setGridWidth (int w);
    bool    isGridMoving ();
    void    setGridMoving (bool moving);
    int     getTimeFrameEachGrid();
    void    setTimeFrameEachGrid (int t);
    void    setAntialiasing (bool antialiasingEnabled);
    bool    isAntialiasingEnabled ();

    void    addNewDataGroup (const char* title);
    vector  <ResourceHistoryDatagroup>* getDatagroups();
    ResourceHistoryDatagroup* getMeanDatagroup();

    //mean line statistic
    float   getMeanValue();
    float   getMeanHighestPeakValue();
    float   getMeanLowestPeakValue();
    string  getMeanLineLabel();
    void    setMeanLineLabel(string label);
    QColor  getMeanLineColor ();
    void    setMeanLineColor (QColor lineColor);
    bool    isMeanLineVisible ();
    void    setMeanLineVisible (bool visible);
    float   getMeanLineWidth ();
    void    setMeanLineWidth (float lineWidth);

};

#endif // RESOURCE_HISTORY_CHART_H
