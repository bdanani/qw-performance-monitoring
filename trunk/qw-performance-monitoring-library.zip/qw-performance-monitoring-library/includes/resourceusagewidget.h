/*
Copyright (c) 2011 by Bob K Danani
See the file license.txt for copying permission.
*/

#ifndef RESOURCE_USAGE_WIDGET_H
#define RESOURCE_USAGE_WIDGET_H

#include "resourceusagebar.h"
#include <vector>
#include <iostream>
#include <sstream>
#include <QtCore/qstring.h>
#include <QtGui/qlabel.h>
#include <QtGui/qcolor.h>
#include <QtGui/qgroupbox.h>
#include <QtGui/qboxlayout.h>
#include <QtGui/qgridlayout.h>
#include <QtGui/qstackedlayout.h>
#include <QtCore/qtimer.h>

using namespace std;

class ResourceUsageWidget : public QWidget
{
    Q_OBJECT

public:
    ResourceUsageWidget();
    ~ResourceUsageWidget();
    QSize   minimumSizeHint() const;
    QSize   sizeHint() const;

    //current value and maximum scale for the values
    float   getMaximumScale ();
    void    setMaximumScale (float maximum);
    float   getCurrentValue();
    void    setCurrentValue(float value);

    //label and title configurations
    QString getMinimumLabelText ();
    void    setMinimumLabelText (QString minimumLabelText);
    void    setMinimumLabelText (char* minimumLabelText);

    QString getMaximumLabelText ();
    void    setMaximumLabelText (QString maximumLabelText);
    void    setMaximumLabelText (char* maximumLabelText);

    QString getTitle ();
    void    setTitle (QString title);
    void    setTitle (char* title);

    int     getGridDensity();
    void    setGridDensity(int gridDensity);

    QColor  getGridBackgroundColor();
    void    setGridBackgroundColor (QColor gridBackgroundColor);

    QColor  getPerformanceBarColor();
    void    setPerformanceBarColor (QColor performanceBarColor);

    QColor  getTextColor ();
    void    setTextColor (QColor textColor);

    //visibility of the performance value (at the bottom of the widget)
    bool    isValueVisible();
    void    setValueVisible(bool visible);

    //the inner widget size (resource usage bar)
    QSize   getInnerBarSize();
    void    setInnerBarSize(QSize size);
    void    setInnerBarSize(int width, int height);

    void    setAntialiasing (bool antialiasingEnabled);
    bool    isAntialiasingEnabled ();

    //update frequency to refresh the display
    long    getUpdateFrequency();
    void    setUpdateFrequency (long updateFrequency);
    void    restartTimer ();

public slots:
     void   modifyTimeFrame();

private:
    float       currentValue;
    QString     minimumLabelText;
    QString     maximumLabelText;
    QColor      textColor;
    QString     title;
    long        updateFrequency; // in millisecond
    QLabel      *minimumValueLabel;
    QLabel      *maximumValueLabel;
    QLabel      *valueLabel;
    bool        showValue;
    QGroupBox   *contentGroupBox;
    QTimer      *timer;

private:
    QString getTextStyleSheet(int red, int green, int blue);

protected:
    ResourceUsageBar *usageBar;
};
#endif // RESOURCE_USAGE_WIDGET_H
