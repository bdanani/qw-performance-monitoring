/*
Copyright (c) 2011 by Bob K Danani
See the file license.txt for copying permission.
*/

#ifndef RESOURCE_HISTORY_WIDGET_H
#define RESOURCE_HISTORY_WIDGET_H

#include "resourcehistorychart.h"
#include "resourcehistorydatagroup.h"
#include <vector>
#include <iostream>
#include <sstream>
#include <QtOpenGL/QGLWidget>
#include <QtGui/qlabel.h>
#include <QtGui/qgroupbox.h>
#include <QtGui/qgridlayout.h>
#include <QtGui/QHBoxLayout>
#include <QtCore/qtimer.h>

using namespace std;

class ResourceHistoryWidget : public QWidget
{
    Q_OBJECT

public:
    //PUBLIC FUNCTIONS
    ResourceHistoryWidget();
    ~ResourceHistoryWidget();
    QSize   minimumSizeHint() const;
    QSize   sizeHint() const;

    long    getUpdateFrequency();
    void    setUpdateFrequency (long updateFrequency);
    void    reInitializeChart();

    int     getTimeFrameEachGrid();
    void    setTimeFrameEachGrid (int t);
    QColor  getGridColor ();
    void    setGridColor (QColor gridColor);
    QColor  getBackgroundColor ();
    void    setBackgroundColor (QColor backgroundColor);
    QColor  getTextColor ();
    void    setTextColor (QColor textColor);

    bool    isGridVisible ();
    void    setGridVisible (bool visible);
    int     getGridHeight ();
    void    setGridHeight (int h);
    int     getGridWidth ();
    void    setGridWidth (int w);
    bool    isGridMoving ();
    void    setGridMoving (bool moving);

    QString getMinimumLabelText ();
    void    setMinimumLabelText (QString minimumLabelText);
    void    setMinimumLabelText (char* minimumLabelText);
    QString getMaximumLabelText ();
    void    setMaximumLabelText (QString maximumLabelText);
    void    setMaximumLabelText (char* maximumLabelText);
    QString getTitle ();
    void    setTitle (QString title);
    void    setTitle (char* title);
    float   getMaximumScale ();
    void    setMaximumScale (float maximum);

    void    setAntialiasing (bool antialiasingEnabled);
    bool    isAntialiasingEnabled ();

    void    addNewDataGroup (const char* title = "");
    void    restartTimer();
    vector  <ResourceHistoryDatagroup>* getDatagroups ();
    ResourceHistoryDatagroup* getMeanDataGroup();

    //mean data statistic
    float   getMeanValue();
    float   getMeanHighestPeakValue();
    float   getMeanLowestPeakValue();
    string  getMeanLineLabel();
    void    setMeanLineLabel(string label);
    QColor  getMeanLineColor ();
    void    setMeanLineColor (QColor lineColor);
    bool    isMeanLineVisible ();
    void    setMeanLineVisible (bool visible);
    float   getMeanLineWidth ();
    void    setMeanLineWidth (float lineWidth);

public slots:
     void   modifyTimeFrame ();

private:
    ResourceHistoryChart *resourceHistoryChart;
    long    updateFrequency; // in millisecond
    QTimer  *timer;

    QString title;
    QString minimumLabelText;
    QString maximumLabelText;

    QLabel  *minimumValueLabel;
    QLabel  *maximumValueLabel;
    QColor  textColor;
    QGroupBox *contentGroupBox;

private:
    QString getTextStyleSheet(int red, int green, int blue);
};

#endif // RESOURCE_HISTORY_USAGE_WIDGET_H
