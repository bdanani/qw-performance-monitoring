#include <QtGui/qapplication.h>
#include <QtGui/qgroupbox.h>
#include <QtGui/qboxlayout.h>
#include <resourcehistorywidget.h>
#include <resourcehistorylegendwidget.h>
#include "mytimerevent.h"

int main(int argc, char *argv[])
{
    const int updateFrequency = 1000; // 1000 milliseconds (1 second)

    QApplication a(argc, argv);
    //ResourceHistoryWidget configuration
    ResourceHistoryWidget *cpuHistoryWidget = new ResourceHistoryWidget();
    cpuHistoryWidget->setFixedSize(500, 375 );

    //OPTIONAL PARAMETER CONFIGURATIONS (Otherwise, use default initialized parameters)
    cpuHistoryWidget->setGridWidth(20); // grid width (optional, if not set, by default grid width is 10)
    cpuHistoryWidget->setGridHeight(20); // grid height (optional, if not set, by default grid height is 10)
    cpuHistoryWidget->setTimeFrameEachGrid(5); // time frame per grid (optional, if not set, by default timeframepergrid is 5)
    cpuHistoryWidget->setMaximumScale(100.0); // maximumScale (optional, if not set, by default maximumScale is 1.0
    cpuHistoryWidget->setUpdateFrequency(updateFrequency); // updateFrequency (optonal, if not set, by default update frequency is every 1000milliseconds => 1 second)

    //ADDING 4 DATAGROUPS
    cpuHistoryWidget->addNewDataGroup("Process 1");
    cpuHistoryWidget->addNewDataGroup("Process 2");
    cpuHistoryWidget->addNewDataGroup("Process 3");
    cpuHistoryWidget->addNewDataGroup("Process 4");
    //CONFIGURE DATAGROUPS
    cpuHistoryWidget->getDatagroups()->at(0).setLineColor(QColor (200, 40, 200));
    cpuHistoryWidget->getDatagroups()->at(1).setLineColor(QColor (20, 200, 20));
    cpuHistoryWidget->getDatagroups()->at(2).setLineColor(QColor (80, 100, 250));
    cpuHistoryWidget->getDatagroups()->at(3).setLineColor(QColor (180, 180, 20));

    //example of how to configure the mean performance line (by default the mean line is not visible, so we have to make it visible explicitly)
    cpuHistoryWidget->setMeanLineVisible(true);
    cpuHistoryWidget->setMeanLineColor(QColor (255, 0, 0)); // color for mean line = red
    cpuHistoryWidget->setMeanLineWidth(3.5); // line width for mean line: 3.5
    cpuHistoryWidget->setMeanLineLabel("Avg Performance");

    //Adding a Legend (RESOUCE HISTORY LEGEND WIDGET)
    ResourceHistoryLegendWidget *legendWidget = new ResourceHistoryLegendWidget();
    //Legend Configuration
    legendWidget->setFixedSize(600, 250);
    //IMPORTANT: add all datagroups (including the mean datagroup) to this legend
    legendWidget->addDatagroup(cpuHistoryWidget->getMeanDataGroup());
    legendWidget->addDatagroup(&cpuHistoryWidget->getDatagroups()->at(0));
    legendWidget->addDatagroup(&cpuHistoryWidget->getDatagroups()->at(1));
    legendWidget->addDatagroup(&cpuHistoryWidget->getDatagroups()->at(2));
    legendWidget->addDatagroup(&cpuHistoryWidget->getDatagroups()->at(3));

    //Optional: Changing Legend Header labels
    legendWidget->setDatagroupLabelText("Processes");
    legendWidget->setValueLabelText("Current");
    //legendWidget->setHighestPeakLabelText("Highest");
    //legendWidget->setLowestPeakLabelText ("Lowest");
    //legendWidget->setColorLabelText("Line Color");

    //Note: we don't change the visibility parameters (as in example 5), so by default all visibility is set to true.

    //layouting configuration
    QVBoxLayout *mainLayout = new QVBoxLayout();
    mainLayout->addWidget(cpuHistoryWidget, 0);
    mainLayout->addWidget(legendWidget, 0);
    QGroupBox *contentGroupBox = new QGroupBox();
    contentGroupBox->setTitle("Performance Monitoring");
    contentGroupBox->setAlignment(Qt::AlignCenter);
    contentGroupBox->setLayout(mainLayout);

    // IMPORTANT: this reinitializeChart() function has to be called after we have finished
    //            setting up all parameters for the ResourceHistoryWidget, in order for these parameters to affect the widget display
    cpuHistoryWidget->reInitializeChart();

    //Note: The constructor for MyTimerEvent now accepts the legendWidget as its parameter (pass by reference)
    //      In this case, the legend data will also be updated when our cpuHistoryWidget chart is updated
    MyTimerEvent *event = new MyTimerEvent(cpuHistoryWidget, legendWidget, updateFrequency);
    event->start();
    contentGroupBox->show();
    return a.exec();
}
