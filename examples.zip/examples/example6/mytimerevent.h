#ifndef MYTIMEREVENT_H
#define MYTIMEREVENT_H

#include <resourcehistorywidget.h>
#include <resourcehistorylegendwidget.h>

class MyTimerEvent : QObject {
    Q_OBJECT
public :
    MyTimerEvent(ResourceHistoryWidget *object, ResourceHistoryLegendWidget *legend, int updateFrequency);
    ~MyTimerEvent();
    void start();
    void stop();
public slots:
    void updatePerformanceValue();
private :
    QTimer *timer;
    ResourceHistoryWidget *cpuHistoryWidget;
    ResourceHistoryLegendWidget *legendWidget;
    int updateFrequency;
};

#endif // MYTIMEREVENT_H
