#include <QtGui/qapplication.h>
#include <resourcehistorywidget.h>
#include "mytimerevent.h"

int main(int argc, char *argv[])
{
    const int updateFrequency = 500; // 500 milliseconds (0.5 second)

    QApplication a(argc, argv);
    //ResourceHistoryWidget initialization
    ResourceHistoryWidget *cpuHistoryWidget = new ResourceHistoryWidget();
    cpuHistoryWidget->setFixedSize(500, 375 ); // widget size

    //OPTIONAL PARAMETER CONFIGURATIONS (Otherwise, use default initialized parameters)
    cpuHistoryWidget->setGridWidth(20); // grid width (optional, if not set, by default grid width is 10)
    cpuHistoryWidget->setGridHeight(20); // grid height (optional, if not set, by default grid height is 10)
    cpuHistoryWidget->setTimeFrameEachGrid(4); // time frame per grid (optional, if not set, by default timeframepergrid is 5)
    cpuHistoryWidget->setMaximumScale(100.0); // maximumScale (optional, if not set, by default maximumScale is 1.0
    cpuHistoryWidget->setUpdateFrequency(updateFrequency); // updateFrequency (optonal, if not set, by default update frequency is every 1000 milliseconds => 1 second)

    //ADDING NEW DATAGROUP LINE TO THE CHART (IMPORTANT, otherwise no performance line is displayed)
    cpuHistoryWidget->addNewDataGroup("Process 1");
    cpuHistoryWidget->getDatagroups()->at(0).setLineColor(QColor (200, 200, 20)); // line color (optional, if not set, by default is 25, 255, 25)


    // IMPORTANT: this reinitializeChart() function has to be called after we have finished
    //            setting up all parameters for the ResourceHistoryWidget, in order for these parameters to affect the widget display
    cpuHistoryWidget->reInitializeChart();

    MyTimerEvent *event = new MyTimerEvent(cpuHistoryWidget, updateFrequency);
    event->start();
    cpuHistoryWidget->show();
    return a.exec();
}
