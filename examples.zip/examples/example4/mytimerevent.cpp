#include "mytimerevent.h"

MyTimerEvent::MyTimerEvent(ResourceHistoryWidget *object, int updateFrequency)
{
    cpuHistoryWidget = object;
    this->updateFrequency = updateFrequency;
    srand(time(NULL)); // to generate the random performance value (for testing purpose)
    timer = new QTimer();
    //connect timer action for calling the updatePerformanceValue function (for testing purpose)
    QObject::connect(timer, SIGNAL(timeout()), this, SLOT(updatePerformanceValue()));
}

MyTimerEvent::~MyTimerEvent(){}

void MyTimerEvent::updatePerformanceValue() {
    double val =  drand48() * 20; // range from 0 - 20.0
    double val2 = drand48() * 20; // range from 0 - 20.0
    cpuHistoryWidget->getDatagroups()->at(0).setCurrentValue(val  + 20.0);
    cpuHistoryWidget->getDatagroups()->at(1).setCurrentValue(val2 + 40.0);
    cpuHistoryWidget->getDatagroups()->at(2).setCurrentValue(val  + 60.0);
    cpuHistoryWidget->getDatagroups()->at(3).setCurrentValue(val2 + 80.0);
}

void MyTimerEvent::start(){
    timer->start(updateFrequency);
}

void MyTimerEvent::stop(){
    timer->stop();
}
