#include <QtGui/qapplication.h>
#include <resourcehistorywidget.h>
#include "mytimerevent.h"

int main(int argc, char *argv[])
{
    const int updateFrequency = 1000; // 1000 milliseconds (1 second)

    QApplication a(argc, argv);
    //ResourceHistoryWidget configuration
    ResourceHistoryWidget *cpuHistoryWidget = new ResourceHistoryWidget();
    cpuHistoryWidget->setFixedSize(500, 375 );

    //OPTIONAL PARAMETER CONFIGURATIONS (Otherwise, use default initialized parameters)
    cpuHistoryWidget->setGridWidth(20); // grid width (optional, if not set, by default grid width is 10)
    cpuHistoryWidget->setGridHeight(20); // grid height (optional, if not set, by default grid height is 10)
    cpuHistoryWidget->setTimeFrameEachGrid(4); // time frame per grid (optional, if not set, by default timeframepergrid is 5)
    cpuHistoryWidget->setMaximumScale(100.0); // maximumScale (optional, if not set, by default maximumScale is 1.0
    cpuHistoryWidget->setUpdateFrequency(updateFrequency); // updateFrequency (optonal, if not set, by default update frequency is every 1000milliseconds => 1 second)

    //ADDING 4 DATAGROUPS
    cpuHistoryWidget->addNewDataGroup("Process 1");
    cpuHistoryWidget->addNewDataGroup("Process 2");
    cpuHistoryWidget->addNewDataGroup("Process 3");
    cpuHistoryWidget->addNewDataGroup("Process 4");
    //CONFIGURE DATAGROUPS
    cpuHistoryWidget->getDatagroups()->at(0).setLineColor(QColor (200, 40, 200));
    cpuHistoryWidget->getDatagroups()->at(1).setLineColor(QColor (20, 200, 20));
    cpuHistoryWidget->getDatagroups()->at(2).setLineColor(QColor (80, 100, 250));
    cpuHistoryWidget->getDatagroups()->at(3).setLineColor(QColor (180, 180, 20));

    //example of how to configure the mean performance line (by default the mean line is not visible, so we have to make it visible explicitly)
    cpuHistoryWidget->setMeanLineVisible(true);
    cpuHistoryWidget->setMeanLineColor(QColor (255, 0, 0)); // color for mean line = red
    cpuHistoryWidget->setMeanLineWidth(3.5); // line width for mean line: 3.5
    cpuHistoryWidget->setMeanLineLabel("Avg Performance");

    // IMPORTANT: this reinitializeChart() function has to be called after we have finished
    //            setting up all parameters for the ResourceHistoryWidget, in order for these parameters to affect the widget display
    cpuHistoryWidget->reInitializeChart();

    MyTimerEvent *event = new MyTimerEvent(cpuHistoryWidget, updateFrequency);
    event->start();
    cpuHistoryWidget->show();
    return a.exec();
}
