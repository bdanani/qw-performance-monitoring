#include <QtGui/qapplication.h>
#include <QtGui/qgroupbox.h>
#include <QtGui/qgridlayout.h>
#include <resourceusagewidget.h>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    ResourceUsageWidget *cpuUsage1 = new ResourceUsageWidget();
    cpuUsage1->setMaximumScale(100.0); // values are in scale of 0 to 100 (by default the scale is 0.0 - 1.0)
    cpuUsage1->setCurrentValue(20.375);
    cpuUsage1->setFixedSize(150, 250);
    cpuUsage1->setTitle("Node 1");

    ResourceUsageWidget *cpuUsage2 = new ResourceUsageWidget();
    cpuUsage2->setMaximumScale(100.0); // values are in scale of 0 to 100 (by default the scale is 0.0 - 1.0)
    cpuUsage2->setCurrentValue(40.75);
    cpuUsage2->setFixedSize(150, 250);
    cpuUsage2->setTitle("Node 2");

    ResourceUsageWidget *cpuUsage3 = new ResourceUsageWidget();
    cpuUsage3->setMaximumScale(100.0); // values are in scale of 0 to 100 (by default the scale is 0.0 - 1.0)
    cpuUsage3->setCurrentValue(74.625);
    cpuUsage3->setFixedSize(150, 250);
    cpuUsage3->setTitle("Node 3");

    ResourceUsageWidget *cpuUsage4 = new ResourceUsageWidget();
    cpuUsage4->setMaximumScale(100.0); // values are in scale of 0 to 100 (by default the scale is 0.0 - 1.0)
    cpuUsage4->setCurrentValue(90.75);
    cpuUsage4->setFixedSize(150, 250);
    cpuUsage4->setTitle("Node 4");

    //CHART OPTIONS GROUP BOX
    QGroupBox *cpuUsageGroupBox = new QGroupBox("CPU Usage");
    cpuUsageGroupBox->setAlignment(Qt::AlignCenter);

    QGridLayout *cpuUsageLayout = new QGridLayout();
    cpuUsageLayout->addWidget(cpuUsage1, 0, 0, 1, 1);
    cpuUsageLayout->addWidget(cpuUsage2, 0, 1, 1, 1);
    cpuUsageLayout->addWidget(cpuUsage3, 0, 2, 1, 1);
    cpuUsageLayout->addWidget(cpuUsage4, 0, 3, 1, 1);

    cpuUsageGroupBox->setLayout(cpuUsageLayout);
    cpuUsageGroupBox->setMinimumSize(600,300);
    cpuUsageGroupBox->show();
    return a.exec();
}
