#ifndef PERFORMANCE_MODULE_H
#define PERFORMANCE_MODULE_H

#include <resourcehistorywidget.h>
#include <resourceusagewidget.h>
#include <resourcehistorylegendwidget.h>

#include <string>
#include <sstream>
#include <QtGui/qwidget.h>
#include <QtGui/qcombobox.h>
#include <QtGui/qpushbutton.h>
#include <QtGui/qcheckbox.h>
#include <QtGui/qlineedit.h>
#include <QtGui/qcolordialog.h>

using namespace std;

class PerformanceModule : public QWidget
{
    Q_OBJECT

public:
    PerformanceModule();
    ~PerformanceModule();
    QString     getButtonStyleSheet(int red, int green, int blue);
    QString     getTextStyleSheet (int red, int green, int blue);

private slots:
    void    setLineWidth();
    void    setBackgroundColor();
    void    setTextColor();
    void    setGridColor();
    void    setPerformanceBarColor();
    void    setGridSize();
    void    restartDisplay();
    void    toggleGridVisibility();
    void    toggleMeanLineVisibility();
    void    toggleMoveGrid();
    void    toggleHighestPeakVisibility();
    void    toggleLowestPeakVisibility();
    void    setTimeframePerGrid();
    void    setUpdateFrequency();
    void    setMinLabel();
    void    setMaxLabel();
    void    updateValue(); // to generate random value for testing purpose

private:
    ResourceHistoryWidget  *cpuHistoryWidget;
    ResourceUsageWidget *cpuUsageWidget1;
    ResourceUsageWidget *cpuUsageWidget2;
    ResourceUsageWidget *cpuUsageWidget3;
    ResourceUsageWidget *cpuUsageWidget4;
    ResourceHistoryLegendWidget *legendWidget;

    QGroupBox   *controlGroupBox;
    QGroupBox   *cpuUsageGroupBox;

    QLabel *backgroundLabel;
    QLabel *gridColorLabel;
    QLabel *textColorLabel;
    QLabel *performanceBarColorLabel;

    QLabel *lineThicknessLabel;
    QLabel *minimumLabel;
    QLabel *maximumLabel;
    QLabel *updateTimeLabel;
    QLabel *timeframePerGridLabel;
    QLabel *gridSizeLabel;

    QLineEdit *updateTimeTextBox;
    QLineEdit *gridSizeTextBox;
    QLineEdit *timeframePerGridTextBox;
    QLineEdit *maxLabelTextBox;
    QLineEdit *minLabelTextBox;

    QCheckBox *showGrid;
    QCheckBox *showMeanLine;
    QCheckBox *moveGrid;
    QCheckBox *showHighestPeak;
    QCheckBox *showLowestPeak;

    QColor backgroundColor;
    QColor gridColor;
    QColor textColor;
    QColor performanceBarColor;

    QPushButton *backgroundColorChooser;
    QPushButton *gridColorChooser;
    QPushButton *textColorChooser;
    QPushButton *performanceBarColorChooser;

    QPushButton *updateDisplay;
    QSlider *lineThicknessSlider;

    QString maxLabelText;
    QString minLabelText;

    QTimer *timer;

    bool gridVisible;
    bool meanLineVisible;
    bool gridMoving;
    bool highestPeakVisible;
    bool lowestPeakVisible;

    float lineThickness;
    int gridSize;
    int timeframePerGrid;
    long updateFrequency; // in millisecond
};

#endif // PERFORMANCE_MODULE_H
