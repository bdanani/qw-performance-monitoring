#include "performancemodule.h"
#include <QtGui/qapplication.h>

using namespace std;

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    PerformanceModule *performanceModuleWidget = new PerformanceModule();
    performanceModuleWidget->show();
    return app.exec();
}
