#include "performancemodule.h"

PerformanceModule::PerformanceModule() : QWidget()
{
    srand(time(NULL)); // to generate the random performance value (for testing purpose)
    gridSize = 15;
    timeframePerGrid = 5;
    updateFrequency = 1000;
    gridVisible  = true;
    meanLineVisible = true;
    gridMoving = true;
    highestPeakVisible = true;
    lowestPeakVisible = true;
    stringstream ss;

    backgroundColor     =  QColor(0,0,0,255);
    gridColor           =  QColor(25,100,25,255);
    textColor           =  QColor(0,0,0,255);
    performanceBarColor =  QColor(25, 255, 25, 255);

    //USAGE HISTORY WIDGET configuration
    cpuHistoryWidget = new ResourceHistoryWidget();
    cpuHistoryWidget->setFixedSize(500, 375 );
    cpuHistoryWidget->setGridWidth(15);
    cpuHistoryWidget->setGridHeight(15);

    cpuHistoryWidget->addNewDataGroup("Core 1");
    cpuHistoryWidget->addNewDataGroup("Core 2");
    cpuHistoryWidget->addNewDataGroup("Core 3");
    cpuHistoryWidget->addNewDataGroup("Core 4");

    cpuHistoryWidget->getDatagroups()->at(0).setLineColor(QColor (200, 40, 200));
    cpuHistoryWidget->getDatagroups()->at(1).setLineColor(QColor (20, 200, 20));
    cpuHistoryWidget->getDatagroups()->at(2).setLineColor(QColor (80, 100, 250));
    cpuHistoryWidget->getDatagroups()->at(3).setLineColor(QColor (180, 180, 20));

    //example of how to configure the mean performance line
    cpuHistoryWidget->setMeanLineColor(QColor (255, 0, 0));
    cpuHistoryWidget->setMeanLineWidth(3.5);
    cpuHistoryWidget->setMeanLineLabel("Avg Performance");
    cpuHistoryWidget->setMeanLineVisible(true);
    cpuHistoryWidget->setMaximumScale(100.0);

    //RESOUCE HISTORY LEGEND WIDGET configuration
    legendWidget = new ResourceHistoryLegendWidget();
    legendWidget->setFixedSize(600, 300);
    legendWidget->addDatagroup(cpuHistoryWidget->getMeanDataGroup());
    legendWidget->addDatagroup(&cpuHistoryWidget->getDatagroups()->at(0));
    legendWidget->addDatagroup(&cpuHistoryWidget->getDatagroups()->at(1));
    legendWidget->addDatagroup(&cpuHistoryWidget->getDatagroups()->at(2));
    legendWidget->addDatagroup(&cpuHistoryWidget->getDatagroups()->at(3));
    legendWidget->refreshLegendData();
    //example: changing the default legend header
    legendWidget->setDatagroupLabelText("Processes");
    legendWidget->refreshLegendHeader();

    //USAGE WIDGET configuration
    cpuUsageWidget1 = new ResourceUsageWidget();
    cpuUsageWidget1->setFixedSize(125, 200);
    cpuUsageWidget1->setTitle("Node 1");
    cpuUsageWidget1->setMaximumScale(100.0);

    cpuUsageWidget2 = new ResourceUsageWidget();
    cpuUsageWidget2->setFixedSize(125, 200);
    cpuUsageWidget2->setTitle("Node 2");
    cpuUsageWidget2->setMaximumScale(100.0);

    cpuUsageWidget3 = new ResourceUsageWidget();
    cpuUsageWidget3->setFixedSize(125, 200);
    cpuUsageWidget3->setTitle("Node 3");
    cpuUsageWidget3->setMaximumScale(100.0);

    cpuUsageWidget4 = new ResourceUsageWidget();
    cpuUsageWidget4->setFixedSize(125, 200);
    cpuUsageWidget4->setTitle("Node 4");
    cpuUsageWidget4->setMaximumScale(100.0);


    //Labels for min and max
    minLabelText =  tr("0 %");
    maxLabelText =  tr("100 %");

    //layouting
    QGridLayout *cpuUsageLayout = new QGridLayout();
    QGridLayout *cpuPerformanceLayout = new QGridLayout();

    cpuUsageLayout->addWidget(cpuUsageWidget1, 0, 0, 1, 1);
    cpuUsageLayout->addWidget(cpuUsageWidget2, 0, 1, 1, 1);
    cpuUsageLayout->addWidget(cpuUsageWidget3, 0, 2, 1, 1);
    cpuUsageLayout->addWidget(cpuUsageWidget4, 0, 3, 1, 1);

    //CHART OPTIONS GROUP BOX
    cpuUsageGroupBox = new QGroupBox(tr("CPU Usage"));
    cpuUsageGroupBox->setAlignment(Qt::AlignCenter);
    cpuUsageGroupBox->setLayout(cpuUsageLayout);
    cpuUsageGroupBox->setMinimumSize(500,200);

    cpuPerformanceLayout->addWidget(cpuHistoryWidget, 0, 0, 2, 4);
    cpuPerformanceLayout->addWidget(cpuUsageGroupBox, 2, 0, 1, 4);

    //OPTION WIDGET
    backgroundLabel = new QLabel (tr("BG"));
    backgroundLabel->setAlignment(Qt::AlignRight);
    textColorLabel = new QLabel (tr("Text"));
    textColorLabel->setAlignment(Qt::AlignRight);
    gridColorLabel = new QLabel (tr("Grid"));
    gridColorLabel->setAlignment(Qt::AlignRight);
    performanceBarColorLabel = new QLabel (tr("Usage Bar"));
    performanceBarColorLabel->setAlignment(Qt::AlignRight);

    lineThicknessLabel = new QLabel (tr("Datagroups line thickness"));
    minimumLabel = new QLabel (tr("Label for Minimum"));
    maximumLabel = new QLabel (tr("Label for Maximum"));
    updateTimeLabel = new QLabel (tr("Update Time (ms)"));
    timeframePerGridLabel = new QLabel (tr("Timeframe/grid"));
    gridSizeLabel = new QLabel (tr("Grid size"));

    //line thickness slider
    lineThickness = 2.0;
    lineThicknessSlider = new QSlider();
    lineThicknessSlider->setOrientation(Qt::Horizontal);
    lineThicknessSlider->setValue(lineThickness);
    lineThicknessSlider->setMinimum(1.0);
    lineThicknessSlider->setMaximum(5.0);

    //textboxes
    updateTimeTextBox       = new QLineEdit();
    maxLabelTextBox         = new QLineEdit();
    minLabelTextBox         = new QLineEdit();
    gridSizeTextBox         = new QLineEdit();
    timeframePerGridTextBox = new QLineEdit();

    ss.str("");
    ss << updateFrequency;
    updateTimeTextBox->setText(QString(ss.str().c_str()));
    updateTimeTextBox->setMinimumWidth(40);

    ss.str("");
    ss << gridSize;
    gridSizeTextBox->setText(QString(ss.str().c_str()));
    gridSizeTextBox->setMinimumWidth(40);

    ss.str("");
    ss << timeframePerGrid;
    timeframePerGridTextBox->setText(QString(ss.str().c_str()));
    timeframePerGridTextBox->setMinimumWidth(40);

    maxLabelTextBox->setText(maxLabelText);
    maxLabelTextBox->setMinimumWidth(40);
    minLabelTextBox->setText(minLabelText);
    minLabelTextBox->setMinimumWidth(40);

    //CHECKBOXES
    showGrid  = new QCheckBox("Grid Visible");
    showGrid->setChecked(gridVisible);
    moveGrid  = new QCheckBox("Grid Moving");
    moveGrid->setChecked(gridMoving);
    showMeanLine  = new QCheckBox("Mean Line Visible");
    showMeanLine->setChecked(meanLineVisible);
    showHighestPeak  = new QCheckBox("Highest Peak");
    showHighestPeak->setChecked(highestPeakVisible);
    showLowestPeak  = new QCheckBox("Lowest Peak");
    showLowestPeak->setChecked(lowestPeakVisible);

    //COLOR CHOOSER
    backgroundColorChooser = new QPushButton();
    backgroundColorChooser->setStyleSheet(getButtonStyleSheet(backgroundColor.red(), backgroundColor.green(), backgroundColor.blue()));
    backgroundColorChooser->setMaximumSize(20, 20);

    gridColorChooser = new QPushButton();
    gridColorChooser->setStyleSheet(getButtonStyleSheet(gridColor.red(), gridColor.green(), gridColor.blue()));
    gridColorChooser->setMaximumSize(20, 20);

    textColorChooser = new QPushButton();
    textColorChooser->setStyleSheet(getButtonStyleSheet(textColor.red(), textColor.green(), textColor.blue()));
    textColorChooser->setMaximumSize(20, 20);

    performanceBarColorChooser = new QPushButton();
    performanceBarColorChooser->setStyleSheet(getButtonStyleSheet(performanceBarColor.red(), performanceBarColor.green(), performanceBarColor.blue()));
    performanceBarColorChooser->setMaximumSize(20, 20);

    //Color Settings
    QHBoxLayout *colorLayout = new QHBoxLayout();
    colorLayout->addWidget(backgroundLabel);
    colorLayout->addWidget(backgroundColorChooser);
    colorLayout->addWidget(gridColorLabel);
    colorLayout->addWidget(gridColorChooser);
    colorLayout->addWidget(textColorLabel);
    colorLayout->addWidget(textColorChooser);
    colorLayout->addWidget(performanceBarColorLabel);
    colorLayout->addWidget(performanceBarColorChooser);

    //CHART OPTIONS GROUP BOX
    controlGroupBox = new QGroupBox(tr("Chart Options"));
    QGridLayout *optionLayout = new QGridLayout();
    optionLayout->setMargin(10);
    optionLayout->setAlignment(Qt::AlignTop);

    //Option Layout contents
    QHBoxLayout *checkBoxLayout = new QHBoxLayout();
    checkBoxLayout->addWidget(showGrid);
    checkBoxLayout->addWidget(moveGrid);
    checkBoxLayout->addWidget(showMeanLine);
    optionLayout->addLayout(checkBoxLayout, 0, 0, 1, 2);;

    optionLayout->addLayout(colorLayout, 1, 0, 1, 2);

    optionLayout->addWidget(gridSizeLabel, 2, 0, 1, 1);
    optionLayout->addWidget(gridSizeTextBox, 2, 1, 1, 2);

    optionLayout->addWidget(timeframePerGridLabel, 3, 0, 1, 1);
    optionLayout->addWidget(timeframePerGridTextBox, 3, 1, 1, 2);

    optionLayout->addWidget(updateTimeLabel, 4, 0, 1, 1);
    optionLayout->addWidget(updateTimeTextBox, 4, 1, 1, 2);

    optionLayout->addWidget(lineThicknessLabel, 5, 0, 1, 1);
    optionLayout->addWidget(lineThicknessSlider,5, 1, 1, 2);

    optionLayout->addWidget(minimumLabel, 6, 0, 1, 1);
    optionLayout->addWidget(minLabelTextBox,6, 1, 1, 2);

    optionLayout->addWidget(maximumLabel, 7, 0, 1, 1);
    optionLayout->addWidget(maxLabelTextBox,7, 1, 1, 2);

    updateDisplay = new QPushButton("Update Display");
    optionLayout->addWidget(updateDisplay, 8, 0, 1, 1);

    optionLayout->addWidget(showHighestPeak,  9, 0, 1, 1);
    optionLayout->addWidget(showLowestPeak, 9, 1, 1, 1);
    optionLayout->addWidget (legendWidget, 10, 0, 2, 2);

    controlGroupBox->setLayout(optionLayout);

    QGridLayout *controlLayout = new QGridLayout();
    controlLayout->addWidget(controlGroupBox, 0, 0, 1, 1);

    //MAIN LAYOUT
    QHBoxLayout *layout = new QHBoxLayout();
    layout->addLayout(cpuPerformanceLayout, 0);
    layout->addLayout(controlLayout, 0);

    //ACTIONS and Timer Slots
    timer = new QTimer(this);
    //connect timer action for calling the update value function (for testing purpose)
    connect(timer, SIGNAL(timeout()), this, SLOT(updateValue()));
    timer->start(updateFrequency);

    //add actions for color choosers Push  Buttons
    connect(backgroundColorChooser, SIGNAL(pressed()), this, SLOT(setBackgroundColor()));
    connect(gridColorChooser, SIGNAL(pressed()), this, SLOT(setGridColor()));
    connect(textColorChooser, SIGNAL(pressed()), this, SLOT(setTextColor()));
    connect(performanceBarColorChooser, SIGNAL(pressed()), this, SLOT(setPerformanceBarColor()));
    connect(lineThicknessSlider, SIGNAL(sliderReleased()), this, SLOT(setLineWidth()));
    connect(showGrid, SIGNAL(toggled(bool)), this, SLOT(toggleGridVisibility()));
    connect(showMeanLine, SIGNAL(toggled(bool)), this, SLOT(toggleMeanLineVisibility()));
    connect(moveGrid, SIGNAL(toggled(bool)), this, SLOT(toggleMoveGrid()));
    connect(showHighestPeak, SIGNAL(toggled(bool)), this, SLOT(toggleHighestPeakVisibility()));
    connect(showLowestPeak, SIGNAL(toggled(bool)), this, SLOT(toggleLowestPeakVisibility()));
    connect(updateTimeTextBox, SIGNAL(textChanged(QString)), this, SLOT(setUpdateFrequency()));
    connect(gridSizeTextBox, SIGNAL(textChanged(QString)), this, SLOT(setGridSize()));
    connect(timeframePerGridTextBox, SIGNAL(textChanged(QString)), this, SLOT(setTimeframePerGrid()));
    connect(minLabelTextBox, SIGNAL(textChanged(QString)), this, SLOT(setMinLabel()));
    connect(maxLabelTextBox, SIGNAL(textChanged(QString)), this, SLOT(setMaxLabel()));
    connect(updateDisplay, SIGNAL(clicked()), this, SLOT(restartDisplay()));

    //set window title, size, and layout
    setWindowTitle(tr("Performance Visualization"));
    this->setMinimumSize(1100,600);
    this->setLayout(layout);
    restartDisplay(); // IMPORTANT, mainly to syncrhonize (restart) timer
}

QString PerformanceModule::getButtonStyleSheet(int red, int green, int blue){
    stringstream ss;
    ss << "background-color: rgb(" << red << "," << green << "," << blue << ")";
    QString s(ss.str().c_str());
    return s;
}

QString PerformanceModule::getTextStyleSheet(int red, int green, int blue){
    stringstream ss;
    ss << "color: rgb(" << red << "," << green << "," << blue << ")";
    QString s(ss.str().c_str());
    return s;
}

PerformanceModule::~PerformanceModule(){

}

void PerformanceModule::setTextColor(){
    QColor color = QColorDialog::getColor(textColor, this);
    if (color.isValid())
    {
        textColor = color;
        textColorChooser->setStyleSheet(getButtonStyleSheet(color.red(), color.green(), color.blue()));
        cpuHistoryWidget->setTextColor(color);
        cpuUsageWidget1->setTextColor(color);
        cpuUsageWidget2->setTextColor(color);
        cpuUsageWidget3->setTextColor(color);
        cpuUsageWidget4->setTextColor(color);
        legendWidget->setTextColor(color);
        controlGroupBox->setStyleSheet(getTextStyleSheet(color.red(), color.green(), color.blue()));
        cpuUsageGroupBox->setStyleSheet(getTextStyleSheet(color.red(), color.green(), color.blue()));
    }
}

void PerformanceModule::setBackgroundColor(){
    QColor color = QColorDialog::getColor(backgroundColor, this);
    if (color.isValid())
    {
        backgroundColor = color;
        backgroundColorChooser->setStyleSheet(getButtonStyleSheet(color.red(), color.green(), color.blue()));
        cpuHistoryWidget->setBackgroundColor(color);
    }
}

void PerformanceModule::setGridColor(){
    QColor color = QColorDialog::getColor(gridColor, this);
    if (color.isValid())
    {
        gridColor = color;
        gridColorChooser->setStyleSheet(getButtonStyleSheet(color.red(), color.green(), color.blue()));
        cpuHistoryWidget->setGridColor(color);
        cpuUsageWidget1->setGridBackgroundColor(color);
        cpuUsageWidget2->setGridBackgroundColor(color);
        cpuUsageWidget3->setGridBackgroundColor(color);
        cpuUsageWidget4->setGridBackgroundColor(color);
    }
}

void PerformanceModule::setPerformanceBarColor(){
    QColor color = QColorDialog::getColor(performanceBarColor, this);
    if (color.isValid())
    {
        performanceBarColor = color;
        performanceBarColorChooser->setStyleSheet(getButtonStyleSheet(color.red(), color.green(), color.blue()));
        cpuUsageWidget1->setPerformanceBarColor(color);
        cpuUsageWidget2->setPerformanceBarColor(color);
        cpuUsageWidget3->setPerformanceBarColor(color);
        cpuUsageWidget4->setPerformanceBarColor(color);
    }
}

void PerformanceModule::toggleGridVisibility(){
    gridVisible = !gridVisible;
    cpuHistoryWidget->setGridVisible(gridVisible);
}

void PerformanceModule::toggleMoveGrid(){
    gridMoving = !gridMoving;
    cpuHistoryWidget->setGridMoving(gridMoving);
}

void PerformanceModule::setLineWidth(){
    lineThickness = lineThicknessSlider->value();
    cpuHistoryWidget->getDatagroups()->at(0).setLineWidth(lineThickness);
    cpuHistoryWidget->getDatagroups()->at(1).setLineWidth(lineThickness);
    cpuHistoryWidget->getDatagroups()->at(2).setLineWidth(lineThickness);
    cpuHistoryWidget->getDatagroups()->at(3).setLineWidth(lineThickness);
}

void PerformanceModule::setGridSize(){
    gridSize = gridSizeTextBox->text().toInt();
}

void PerformanceModule::setTimeframePerGrid(){
    timeframePerGrid = timeframePerGridTextBox->text().toInt();
}

void PerformanceModule::setUpdateFrequency(){
     updateFrequency = updateTimeTextBox->text().toLong();
}

void PerformanceModule::restartDisplay(){
    cpuHistoryWidget->setBackgroundColor(backgroundColor);
    cpuHistoryWidget->setGridColor(gridColor);
    cpuHistoryWidget->setGridHeight(gridSize);
    cpuHistoryWidget->setGridWidth(gridSize);
    cpuHistoryWidget->setTimeFrameEachGrid(timeframePerGrid);
    cpuHistoryWidget->setUpdateFrequency(updateFrequency);
    cpuHistoryWidget->reInitializeChart();

    cpuUsageWidget1->setUpdateFrequency(updateFrequency);
    cpuUsageWidget2->setUpdateFrequency(updateFrequency);
    cpuUsageWidget3->setUpdateFrequency(updateFrequency);
    cpuUsageWidget4->setUpdateFrequency(updateFrequency);

    timer->stop();
    cpuHistoryWidget->restartTimer();
    cpuUsageWidget1->restartTimer();
    cpuUsageWidget2->restartTimer();
    cpuUsageWidget3->restartTimer();
    cpuUsageWidget4->restartTimer();

    timer->start(updateFrequency);
}

void PerformanceModule::setMaxLabel(){
    maxLabelText =  maxLabelTextBox->text();
    cpuUsageWidget1->setMaximumLabelText(maxLabelText);
    cpuUsageWidget2->setMaximumLabelText(maxLabelText);
    cpuUsageWidget3->setMaximumLabelText(maxLabelText);
    cpuUsageWidget4->setMaximumLabelText(maxLabelText);
    cpuHistoryWidget->setMaximumLabelText(maxLabelText);
}

void PerformanceModule::setMinLabel(){
    minLabelText =  minLabelTextBox->text();
    cpuUsageWidget1->setMinimumLabelText(minLabelText);
    cpuUsageWidget2->setMinimumLabelText(minLabelText);
    cpuUsageWidget3->setMinimumLabelText(minLabelText);
    cpuUsageWidget4->setMinimumLabelText(minLabelText);
    cpuHistoryWidget->setMinimumLabelText(minLabelText);
}

void PerformanceModule::toggleMeanLineVisibility(){
    meanLineVisible = !meanLineVisible;
    cpuHistoryWidget->setMeanLineVisible(meanLineVisible);
    legendWidget->updateDatagroup(0, cpuHistoryWidget->getMeanDataGroup());
    legendWidget->refreshLegendData();
}

void PerformanceModule::toggleHighestPeakVisibility(){
    highestPeakVisible = !highestPeakVisible;
    legendWidget->setHighestPeakValueVisible(highestPeakVisible);
}

void PerformanceModule::toggleLowestPeakVisibility(){
    lowestPeakVisible = !lowestPeakVisible;
    legendWidget->setLowestPeakValueVisible(lowestPeakVisible);
}

void PerformanceModule::updateValue () {
    double val =  drand48() * 20; // range from 0 - 20.0
    double val2 = drand48() * 20; // range from 0 - 20.0

    cpuHistoryWidget->setMaximumScale(100.0);
    cpuHistoryWidget->getDatagroups()->at(0).setCurrentValue(val  + 20.0);
    cpuHistoryWidget->getDatagroups()->at(1).setCurrentValue(val2 + 40.0);
    cpuHistoryWidget->getDatagroups()->at(2).setCurrentValue(val  + 60.0);
    cpuHistoryWidget->getDatagroups()->at(3).setCurrentValue(val2 + 80.0);

    cpuUsageWidget1->setCurrentValue(val  + 20.0);
    cpuUsageWidget2->setCurrentValue(val2 + 40.0);
    cpuUsageWidget3->setCurrentValue(val  + 60.0);
    cpuUsageWidget4->setCurrentValue(val2 + 80.0);

    legendWidget->updateDatagroup(0, cpuHistoryWidget->getMeanDataGroup());
    legendWidget->updateDatagroup(1, &cpuHistoryWidget->getDatagroups()->at(0));
    legendWidget->updateDatagroup(2, &cpuHistoryWidget->getDatagroups()->at(1));
    legendWidget->updateDatagroup(3, &cpuHistoryWidget->getDatagroups()->at(2));
    legendWidget->updateDatagroup(4, &cpuHistoryWidget->getDatagroups()->at(3));
    legendWidget->refreshLegendData();
}
