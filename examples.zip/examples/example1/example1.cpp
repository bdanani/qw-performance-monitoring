/*
Copyright (c) 2011 by Bob K Danani
See the file license.txt for copying permission.
*/

#include <QtGui/qapplication.h>
#include <resourceusagewidget.h>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    ResourceUsageWidget *cpuUsage = new ResourceUsageWidget();
    cpuUsage->setMaximumScale(100.0); // values are in scale of 0 to 100 (by default the scale is 0.0 - 1.0)
    cpuUsage->setCurrentValue(60.575);
    cpuUsage->setGridDensity(200);
    cpuUsage->setFixedSize(200, 400);
    cpuUsage->setTitle("CPU Usage");
    cpuUsage->show();
    return a.exec();
}
